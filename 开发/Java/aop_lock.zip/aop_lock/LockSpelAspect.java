package com.company.procedure.general.lock;

import com.company.configuration.tools.SpelUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Aspect
@Order(Integer.MAX_VALUE - 2)
public class LockSpelAspect extends BaseLockProcessor {

    @Order(Integer.MAX_VALUE - 2)
    @Around("@annotation(lockSpel)")
    public Object login(ProceedingJoinPoint proceedingJoinPoint, LockSpel lockSpel) throws Throwable {
        return lockProceeding(proceedingJoinPoint, SpelUtils.getValue(proceedingJoinPoint, lockSpel.key()),
                lockSpel.waitTime(), lockSpel.leaseTime(), lockSpel.timeUnit());
    }

}
