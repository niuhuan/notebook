package com.company.procedure.general.lock;

import java.lang.annotation.*;
import java.util.concurrent.TimeUnit;

@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface LockWalletService {

    int waitTime();

    int leaseTime();

    TimeUnit timeUnit();

}
