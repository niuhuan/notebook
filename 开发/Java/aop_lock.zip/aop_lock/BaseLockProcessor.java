package com.company.procedure.general.lock;

import com.company.procedure.general.base.BaseComponent;
import org.aspectj.lang.ProceedingJoinPoint;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.concurrent.TimeUnit;

public class BaseLockProcessor extends BaseComponent {

    @Autowired
    private RedissonClient redissonClient;

    protected Object lockProceeding(ProceedingJoinPoint proceedingJoinPoint, String lockKey, int waitTime, int leaseTime, TimeUnit timeUnit) throws Throwable {
        RLock lock = redissonClient.getLock(lockKey);
        if (lock.tryLock(waitTime, leaseTime, timeUnit)) {
            try {
                return proceedingJoinPoint.proceed();
            } finally {
                lock.unlock();
            }
        } else {
            throw error("您操作过于频繁");
        }
    }
}
