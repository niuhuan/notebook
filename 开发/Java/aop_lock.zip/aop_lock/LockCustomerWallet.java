package com.company.procedure.general.lock;

import java.lang.annotation.*;
import java.util.concurrent.TimeUnit;

@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface LockCustomerWallet {


    String customerId();

    int waitTime();

    int leaseTime();

    TimeUnit timeUnit();

}
