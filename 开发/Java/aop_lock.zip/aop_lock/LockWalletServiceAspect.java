package com.company.procedure.general.lock;

import com.company.procedure.api.base.ApiSessionManager;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;


@Component
@Aspect
@Order(Integer.MAX_VALUE - 3)
public class LockWalletServiceAspect extends BaseLockProcessor {

    @Autowired
    private ApiSessionManager apiSessionManager;

    @Order(Integer.MAX_VALUE - 2)
    @Around("@within(lockWalletService)")
    public Object lockWallet(ProceedingJoinPoint proceedingJoinPoint, LockWalletService lockWalletService) throws Throwable {
        Integer customerId = apiSessionManager.threadLookup();
        if (customerId == null) throw error("错误的调用");
        return lockProceeding(proceedingJoinPoint, "KDY_LOCK::CUSTOMER_WALLET::" + customerId,
                lockWalletService.waitTime(), lockWalletService.leaseTime(), lockWalletService.timeUnit());
    }

}
