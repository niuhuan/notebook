package com.company.procedure.general.lock;

import com.company.configuration.tools.SpelUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;


@Component
@Aspect
@Order(Integer.MAX_VALUE - 3)
public class LockCustomerWalletAspect extends BaseLockProcessor {

    @Order(Integer.MAX_VALUE - 2)
    @Around("@annotation(lockCustomerWallet)")
    public Object lockWallet(ProceedingJoinPoint proceedingJoinPoint, LockCustomerWallet lockCustomerWallet) throws Throwable {
        return lockProceeding(proceedingJoinPoint, "KDY_LOCK::CUSTOMER_WALLET::" + SpelUtils.getValue(proceedingJoinPoint, lockCustomerWallet.customerId()),
                lockCustomerWallet.waitTime(), lockCustomerWallet.leaseTime(), lockCustomerWallet.timeUnit());
    }

}
